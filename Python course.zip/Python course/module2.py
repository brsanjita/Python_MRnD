__author__ = 'Kalyan'


# this is a sample module for the understanding_modules assignment.

def greet(name):
    return "module2 says hi to " + name
