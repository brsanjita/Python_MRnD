__author__ = 'Kalyan'

#  *****   DO NOT MODIFY THIS FILE. *****
#
#
#
# THIS IS A HELPER UTILITY USED IN LESSONS AND ASSIGNMENTS
# IT EXPORTS A FEW CONSTANTS WHICH ARE USED TO ENSURE THAT LESSONS AND ASSIGNMENTS
# DO NOT SHOW COMPILATION ERRORS IN THE IDE.

__all__ = ["__", "___"]

__ = "--Replace me with expected value or True/False --"
___ = 0    # Placeholder for false or numeric