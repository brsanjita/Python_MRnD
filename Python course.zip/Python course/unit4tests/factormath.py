#import placeholders.*

def primenums(stop):
    prime = []
    n = 2
    while n < (stop/2)+1 :
        count = 0
        for i in range(1, n):
            if (n % i == 0):
                count = count + 1
        if (count == 1 and stop%n==0):
            prime.append(n)
        n = n + 1
    return prime

#assert [2,3,5] ==  primenums(30)

def factorise(stop):
    f=[]
    prime=primenums(stop)
    n=len(prime)
    for i in range(n):
        c=0
        d=stop
        while True:
            a=d%prime[i]
            d=d//prime[i]
            if(a==0):
                c=c+1
            else:
                break
        f.append((prime[i],c))
    return f

#assert [(2,2),(5,2)] == factorise(100)

def multiply(*input):
    d = {k: v for k, v in input[0]}
    for i in input[1]:
        if i[0] in d.keys():
            d[i[0]] = d[i[0]] + i[1]
        else:
            d[i[0]] = i[1]
    return sorted([(k,v) for k,v in d.items()])


def get_hcf(*input):
    s_primef_1 = set([a[0] for a in input[0]])
    s_primef_2 = set([a[0] for a in input[1]])
    s_common = s_primef_1 & s_primef_2

    d1 = {k: v for k, v in input[0]}
    d2 = {k: v for k, v in input[1]}

    hcf = [(i, min(d1[i], d2[i])) for i in s_common]
    return sorted(hcf)

def get_lcm(*input):
    s_primef_1 = set([a[0] for a in input[0]])
    s_primef_2 = set([a[0] for a in input[1]])
    s_common = s_primef_1 & s_primef_2

    d1 = {k: v for k, v in input[0]}
    d2 = {k: v for k, v in input[1]}

    tot1 = [(i, d1[i]) for i in d1]
    tot1.extend([(i, d2[i]) for i in d2])

    hcf = [(i, min(d1[i], d2[i])) for i in s_common]
    lcm = list(set(tot1) - set(hcf))
    return sorted(lcm)